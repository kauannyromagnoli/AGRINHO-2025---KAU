 function setup() {
  createCanvas(500, 400);
}

let xJogador = [0, 0, 0, 0];
let yJogador = [50, 160, 250, 350];
let jogador = ["🥚", "🥛", "🍫", "🍓"]
let teclas = ["a", "s", "d", "f"];
let quantidade = jogador.length;

function draw() {
  ativaJogo();
  desenhaJogadores();
  desenhaLinhaDeChegada();
  verificaVencedor(); 
}

 function ativaJogo() {
  if (focused == true) {
  background("#F381A8");
  } else {
    background("#00BCD4");
    fill('#E91E63')
  textFont('Cooper Black')
  text("GOSTO DO CAMPO",140,115)
  textSize(17)
  text("É um jogo de corrida, jogue com um ou mais amigos, assim cada jogador podera ser um emoji e competir, jogo inicia quando clicar na tela, logo depois para fazer eles andar é só clicar nas teclas: A,S,D,F",120,170,200)
 }
    
}
  
  


function desenhaJogadores() {
  if(focused == true){
      textSize(40);
  for (let i = 0; i < quantidade; i++) {
    text(jogador[i], xJogador[i], yJogador[i]);}
  }
  
}

function desenhaLinhaDeChegada() {
  fill("white");
  rect(350, 0, 10, 400);
  fill("black");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function verificaVencedor() {
  for (let i = 0; i < quantidade; i++) {
    if (xJogador[i] > 350) {
      text(jogador[i] + " venceu!", 50, 200);
      noLoop();
    }
  }
}

function keyReleased() {
  for (let i = 0; i < quantidade; i++) {
    if (key == teclas[i]) {
      xJogador[i] += random(20);
    }
  }
}



